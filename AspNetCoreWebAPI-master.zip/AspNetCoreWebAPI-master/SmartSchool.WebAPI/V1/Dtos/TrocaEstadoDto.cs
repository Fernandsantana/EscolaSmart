namespace SmartSchool.WebAPI.V1.Dtos
{
    public class TrocaEstadoDto
    {
        public bool Estado { get; set; }
    }
}