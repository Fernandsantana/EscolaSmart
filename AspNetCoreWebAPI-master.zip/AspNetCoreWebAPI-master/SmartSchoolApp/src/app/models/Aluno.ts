export class Aluno {
  id: number;
  nome: string;
  sobrenome: string;
  telefone: number;
  ativo: boolean;
}
