
export class Disciplina {
  id: number;
  nome: string;
  professorId: number;
}
