export const environment = {
  production: true,
  mainUrlAPI: 'http://localhost:5000/api/'
};
